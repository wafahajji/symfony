<?php

namespace Sonata\AdminBundle\Tests\Fixtures\Controller;

/**
 * Some documentation about Bar controller
 */
class BarAdminController
{
    /**
     * Bar action
     */
    public function barAction()
    {
    }
}
