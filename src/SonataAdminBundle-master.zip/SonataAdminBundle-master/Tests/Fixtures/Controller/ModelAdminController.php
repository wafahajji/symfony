<?php

namespace Sonata\AdminBundle\Tests\Fixtures\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class ModelAdminController extends CRUDController
{

}
