<?php

namespace Sonata\AdminBundle\Tests\Fixtures\Controller;

/**
 * Some documentation about abstract controller
 */
abstract class AbstractFooAdminController
{
    /**
     * Bar action
     */
    public function bazAction()
    {
    }
}
