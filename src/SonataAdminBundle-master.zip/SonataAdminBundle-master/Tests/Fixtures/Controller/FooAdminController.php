<?php

namespace Sonata\AdminBundle\Tests\Fixtures\Controller;

use Sonata\AdminBundle\Tests\Fixtures\Controller\AbstractFooAdminController;

/**
 * Some documentation about Foo controller
 */
class FooAdminController extends AbstractFooAdminController
{
    /**
     * Foo action
     */
    public function fooAction($baz)
    {
    }
}
